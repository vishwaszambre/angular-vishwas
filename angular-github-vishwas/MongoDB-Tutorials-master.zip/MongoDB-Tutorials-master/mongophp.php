<?php
$m = new MongoClient();
$db = $m->birds;
echo "Connected to database birds";
?>