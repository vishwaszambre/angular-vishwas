# MongoDB-Tutorials

Use the employees.json file to perform basic commands.

Use the .js files to work with NodeJS and MongoDB.

Use the .php files to work with PHP and MongoDB.
