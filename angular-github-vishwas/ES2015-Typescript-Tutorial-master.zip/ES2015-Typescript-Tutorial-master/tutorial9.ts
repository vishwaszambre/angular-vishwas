const PI = 3.14;
const MAX_RADIUS = 10;