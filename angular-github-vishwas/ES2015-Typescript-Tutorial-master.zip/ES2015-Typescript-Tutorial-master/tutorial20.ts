
let colors = ['Red', 'Blue', 'Green'];

for(let index in colors){
    console.log(colors[index]);
    
}

for(let color of colors){
    console.log(color);
    
}

let letters = "ABC";

for(let letter of letters){
    console.log(letter);
    
}