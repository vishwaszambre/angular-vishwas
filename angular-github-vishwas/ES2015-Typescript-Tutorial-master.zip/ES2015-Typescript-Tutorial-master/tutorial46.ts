let strArr1: string[] = ['Hello','world'];
let strArr2: Array<string> = ['Hello', 'world'];

let anyArr: any[] = ['Hello', 10, true];

let myTuple: [string, number] = ["Hi", 10];
console.log(myTuple[0]);
console.log(myTuple[1]);
myTuple[2] = 100;
console.log(myTuple[2]);

