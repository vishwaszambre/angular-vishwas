let employee = ["Chandler", "Bing", "Female"];

let [fname, lname, gender="Male"] = employee;

console.log(fname);
console.log(lname);
console.log(gender);
