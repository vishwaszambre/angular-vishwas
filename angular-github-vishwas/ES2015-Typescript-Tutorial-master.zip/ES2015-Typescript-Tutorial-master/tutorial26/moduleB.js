 let fname = "Chandler";
 let lname = "Bing";

 let obj = {
     name: "Joey"
 };
console.log('Module B loaded');
 export {fname, lname, obj}