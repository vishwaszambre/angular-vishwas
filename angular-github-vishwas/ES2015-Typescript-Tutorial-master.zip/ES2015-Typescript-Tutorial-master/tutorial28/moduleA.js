import {greet, GreetMessage} from './moduleB.js'

greet("Hello World");

let gm = new GreetMessage();
gm.greet();