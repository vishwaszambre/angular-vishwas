let ln = "last name";
let person = {
  "first name": "Chandler",
  [ln]: "Bing"
};
console.log(person);


