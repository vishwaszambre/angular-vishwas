enum EyeColor {Brown=1, Black=5, Blue=10};

var myEyeColor = EyeColor.Brown;

console.log(myEyeColor);
console.log(EyeColor[myEyeColor]);
