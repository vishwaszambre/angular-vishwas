var info: any;
info = 10;
info = "Hello";
info = true;

var information;