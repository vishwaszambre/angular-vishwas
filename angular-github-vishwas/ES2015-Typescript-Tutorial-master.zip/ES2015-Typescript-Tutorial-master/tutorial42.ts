var n1 = 10;

//n1 = "Hi";


var n2 = n1 + "Hello";
console.log(n2);
