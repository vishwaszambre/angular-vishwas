
let user = "Chandler";

let greet = `Welcome 'single' "double" ${user} to ES2015
            This is the second line.
               Third and so          on.

`;

console.log(greet);
