import {default as f } from './moduleB.js'

console.log(f);