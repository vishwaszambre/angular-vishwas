var n1 = 10;

//n1 = "Hello";

//var n2 = n1 + 10;
var n2 = n1 + "Hello";
console.log(n2);