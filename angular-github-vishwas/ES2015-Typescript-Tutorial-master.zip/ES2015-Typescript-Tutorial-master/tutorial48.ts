interface Person{
    fname: string;
    lname: string;
    age?: number;
}

let employee1: Person = {
    fname:"Chandler",
    lname:"Bing",
    age:30
}

let employee2: Person ={
    fname:"Ross",
    lname:"Geller"
}